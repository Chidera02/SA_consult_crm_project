The following people have contributed code, patches, bug fixes, and language
translations to the Fat Free CRM:

  * Aaron Brethorst
  * Adis Osmonov ªº
  * Adrian Klingel
  * Ain Tohvri
  * Alejandro
  * Aleksander Madland Stapnes
  * Alexander Kabanov
  * Alex Tomlins
  * AndrewsHerrera
  * Anton Oslyak
  * Antonin Steinhauser
  * Apirak
  * Apirak Panatkool
  * Ashwin Phatak
  * Avery Pennarun
  * Ben Tillman
  * Brook
  * Bryan Helmkamp
  * Chris Carter
  * Codemis
  * Cody Swann
  * Daniel Jabbour
  * Daniel O'Connor
  * Danilo Lacoste
  * David Chua
  * David Cornu
  * David Keita
  * David Westerink
  * deppbot
  * Dirk Kelly
  * DmitriySalko
  * Dmitry
  * Dmitry Avramets
  * Dmitry Dudin
  * Douglas Campos
  * Drew Neil
  * dup2
  * Electron-libre
  * Enderson Maia
  * Eric Shelley
  * François Koessler
  * Fritz Thielemann
  * Gaston Arbeletche -VAIRIX-
  * Gavin Baker
  * Grzegorz Unijewski
  * guesxy
  * James Cook
  * James Zhang
  * Jan Schulz-Hofen
  * Jim Gay
  * johnnyshields
  * Johnny Shields
  * John W. M. Carneiro
  * Josef Chmel
  * jose-gordo
  * jose.gordo
  * Jose Luis Gordo
  * Jose Luis Gordo Romero
  * Joseph Near
  * Josh Adams
  * Kamil Politowicz
  * ken-wong
  * Kevin Fullerton
  * Kiran Jonnalagadda
  * Kouichi Kishikami
  * Koustubh Sinkar
  * Lana Dvorkin
  * Lincoln Lee
  * Louis Nyffenegger
  * Lukasz Kosewski
  * m
  * Malachai
  * Marcelo M. Leal
  * Marian Mrózek
  * Mark Friedgan
  * Martin Gajdos
  * Martin Trejo
  * Martin Villero
  * Masaki Muranaka
  * Matthew Lehner
  * Mauro Alloro
  * Michael Dvorkin
  * Mike Dvorkin
  * Murray Steele
  * Nathan B
  * Nathan Broadbent
  * Nicholas Fine
  * Nicholas Rowe
  * Nicolas Leger
  * nigh7m4r3
  * Nobuhito OKADA
  * Olle Jonsson
  * Olmo Maldonado
  * orthographic-pedant
  * papilip
  * Patrick Mulder
  * Paul
  * Peter McCurdy
  * Philipp Ullmann
  * Ralf Ebert
  * Reuben Salagaras
  * rickerbh
  * Rit Li
  * Road Tang
  * Robert Fletcher
  * Rob Esposito
  * Roman Smirnov
  * Ryan Stenhouse
  * Satoru Ishikawa
  * Scott
  * Scott Dudley
  * Scott Miller
  * Sebastian Castro
  * Seb Jacobs
  * Serafim Junior Dos Santos Fagundes
  * Stanley Hansen
  * Steve Kenworthy
  * steveyken
  * Szeto Bo
  * tarbalazs
  * Thomas Pike
  * Tim Adler
  * Todd Makinster
  * Tom Meier
  * Trevor Oke
  * William Lawson
  * Xughaa
  * Yann Hourdel
  * Yury Kotlyarov
  * Zlatko Zahariev

Generated using "git shortlog -s -n | cut -f 2 | sort"
